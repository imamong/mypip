import platform

is_pypy = platform.python_implementation() == 'PyPy'
