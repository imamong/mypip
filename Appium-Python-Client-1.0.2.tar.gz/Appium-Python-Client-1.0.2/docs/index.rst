.. Appium python client documentation master file, created by
   sphinx-quickstart on Sun May 10 14:33:16 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Appium python client's documentation!
================================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   webdriver


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
