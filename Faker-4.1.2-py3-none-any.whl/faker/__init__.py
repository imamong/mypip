from faker.factory import Factory  # noqa F401
from faker.generator import Generator  # noqa F401
from faker.proxy import Faker  # noqa F401

VERSION = '4.1.2'
