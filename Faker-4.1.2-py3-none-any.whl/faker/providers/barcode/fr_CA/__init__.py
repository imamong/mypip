from ..en_CA import Provider as BarcodeProvider


class Provider(BarcodeProvider):
    pass
